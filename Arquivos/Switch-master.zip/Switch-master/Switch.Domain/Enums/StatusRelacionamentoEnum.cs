﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Switch.Domain.Enums
{
    public enum StatusRelacionamentoEnum
    {
        NaoEspecificado = 1,
        Solteiro = 2,
        Casado = 3,
        EmRelacionamentoSerio=4
    }
}
