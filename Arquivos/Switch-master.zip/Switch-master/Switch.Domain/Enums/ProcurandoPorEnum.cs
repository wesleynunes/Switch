﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Switch.Domain.Enums
{
    public enum ProcurandoPorEnum
    {
        NaoEspecificado = 1,
        Namoro = 2,
        Amizade = 3,
        RelacionamentoSerio=4
    }
}
